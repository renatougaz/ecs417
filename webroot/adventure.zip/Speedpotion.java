
public class Speedpotion extends usableItem
{

    public Speedpotion()
    {
        this.setSpeed(15);
        this.setName("Speed potion");
    }
    public void use(){
        
    }

}
