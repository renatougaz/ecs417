import java.io.*;
import java.util.Random;
public abstract class Enemy extends Character implements fighter,Serializable
{
    private int strength;
    private int health;
    private int speed;
    private int defence;
    private int tempDefence;
    private int currentHealth;
    
    private Weapon weaponDrop;
    public Enemy(){
        super("Enemy");
        weaponDrop = new Weapon(new Random().nextInt(3)+1);
    }
    public void defend(){ 
        tempDefence += this.strength * 0.5;
    }
    
    
    public void attack(fighter enemy){
        int damage = strength - enemy.getTempDefence()+enemy.getDefence();
        if (damage < 0){
            damage = 0;
        }
        enemy.setDamage(damage);
        enemy.setTempDefence(0);
    }
    
    
    public void setCurrentHealth(int currentHealth){
        this.currentHealth = currentHealth;
    }
    
    
    public void setDamage(int damage){
        this.currentHealth -= damage;
    }
    
    
    public  void setSpeed(int speed){
        this.speed = speed;
    }
    
    
    public int getStrength(){
        return strength;
    }
    
    
    public void setStrength(int strength){
        this.strength = strength;
    }
    
    
    public int getHealth(){
        return health;
    }
    
    
    public void setHealth(int health){     
        this.health = health;
    }
    
    
    public int getCurrentHealth(){
        return currentHealth;
    }
    
    
    public int getDefence(){
        return defence;
    }
    
    
    public void setDefence(int defence){
        this.defence = defence;
    }
    
    
    public int getTempDefence(){
        return tempDefence;
    }
        
    
    public void setTempDefence(int defence){
        tempDefence = defence;
    }
        
    
    public int getSpeed(){
        return speed;
    }
    
    
    public item getItem(){
        if(this.currentHealth == 0){
            return null;
        
        }
        else{
            return weaponDrop;
        }
    }
    
    abstract public String randAction(fighter enemy);
        
    
}
