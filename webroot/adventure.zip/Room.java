import java.util.Random;
import java.io.*;
abstract public class Room implements Serializable
{
    final private int maxInstanceOfRoom = 5;
    private Room[] nextRooms;
    private int numOfRooms;
    private int roomNum;
    public Room(int roomNum){
        numOfRooms = new Random().nextInt(3) +1;
        nextRooms = new Room[numOfRooms];
        this.roomNum = roomNum;
    }
    
    
    public Room(){
        numOfRooms = new Random().nextInt(3) +1;
        nextRooms = new Room[numOfRooms];
        roomNum = 1;
    }
    
    
    public void generateRooms(){
             
             for (int i = 0; i<this.getNumOfRooms();i++){ 
                 
                    if(roomNum == -1){
                        return;
                    }
                    if (roomNum < maxInstanceOfRoom){
                        if (Math.random()>0.5){
                            this.setNextRooms(new safeRoom(roomNum+1),i);
                        }
                        else{
                            this.setNextRooms(new battleRoom(roomNum+1),i);
                        }
                    }
                    else{  
                        if (Math.random()>0.7){
                            this.setNextRooms(new safeRoom(roomNum+1),i);
                        }
                        else{
                            if (Math.random() > 0.3){
                                this.setNextRooms(new bossRoom(-1),i);
                            }
                            else{
                                this.setNextRooms(new battleRoom(roomNum+1),i);
                            }
                        }
                    }
                }
            }

        
    public int getNumOfRooms(){
        return numOfRooms;
    }
        
    
    public Room[] getNextRooms(){
        return nextRooms;
    }
        
    
    public Room getNextRooms(int i){
        return nextRooms[i];
    }
    
    
    public void setNextRooms(Room newRoom,int num){
        nextRooms[num] = newRoom;
    }
        
    
    public  Inmune getInmune(){
        return null;
    }
        
    
    public Enemy getEnemy(){
        return null;
    }
        
    
}
