import java.util.*;
public class weaponInmune extends Inmune
{
    public weaponInmune()
    {
        super();
        
        setOffering(new Weapon(new Random().nextInt(3)+1));
    }
        
    
    public weaponInmune(int weaponType)
    {
        super();
        setOffering(new Weapon(weaponType));
    }
        
    

        
    
}
