
import java.util.Random;
public class bossRoom extends Room
{
    Doctor enemy;
    public bossRoom(int roomNum)
    {
        super(roomNum);
        enemy = new Doctor(Game.getNames()[new Random().nextInt(Game.getNames().length)]);
    }
        
    
    public Doctor getEnemy(){
        return enemy;
    }

}
