

public class Strong extends Maincharacter 
{

    public Strong(String name)
    {
        super(name);
        this.setSpeed(10);
        this.setStrength(40);
        this.setHealth(100);
        this.setDefence(10);
        this.setCurrentHealth(this.getHealth());
        this.setFirstWeapon(2);
    }
    public void useItem(){
        
    }
    public void specialAbility(){
    
        
    }

 
}
