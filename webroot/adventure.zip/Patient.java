final public class Patient extends Maincharacter 
{
    private int firstWeapon;
    public Patient(String name)
    {
        super(name);
        this.setSpeed(20);
        this.setStrength(20);
        this.setHealth(100);
        this.setDefence(20);
        this.setCurrentHealth(this.getHealth());
        this.setFirstWeapon(1);
        
    }
    public void useItem(){
        
    }
    public void specialAbility(){
    
        
    }
   
    

}
