import java.io.*;
abstract public class Character implements Serializable
{
    private final String name;
    
    public Character(String name)
    {
        this.name = name;
    }


    public String getName()
    {
        return name;
    }
    public item getItem(){
       return null; 
    }
    
    public void attack(){
      
    }
    
}
