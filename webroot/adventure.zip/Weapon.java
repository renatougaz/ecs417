

final public class Weapon extends item{
    private int speedMod;
    private int strengthMod;
    private int defenceMod;
    public Weapon(int type){
        if (type == 0){
            setName("fists");
            speedMod = 0;
            strengthMod = 0;
            defenceMod = 10;
        }
        else if(type == 1){
            setName("Sword");
            speedMod = 20;
            strengthMod = 20;
            defenceMod = 10;
        }
        else if (type == 2){
            setName("Hammer");
                speedMod = 0;
                strengthMod = 40;
                defenceMod = 10;
                
            }
        else{
            setName("Knife");
            speedMod = 30;
            strengthMod = 20;
            defenceMod = 0;
        }
    }
        



}
