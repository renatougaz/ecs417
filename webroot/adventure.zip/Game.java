import java.util.*;
import java.io.*;
final public class Game implements Serializable
{   
     private Maincharacter mc; 
     private int currentRoomNum; 
     private ArrayList<Room> rooms;
     private Room currentRoom;
     private Character currentEnemy;
     private Inmune currentInmune;
     int[] tempStats;
    public Game(int charClass,String name){
        currentRoomNum = 0;
        rooms = new ArrayList<Room>();
        tempStats = new int[3];

        if(charClass ==0){
            mc = new Patient(name);
        }
        else if(charClass == 1){
            mc = new Strong(name);
        }
        else {
            mc = new Quick(name);
        }
        
        //the first room the player visits is always a weapon room and the weapon they get depnds on the type of main character
        rooms.add(new safeRoom(0,mc.getFirstWeapon()));
        currentRoom = rooms.get(currentRoomNum);
        currentInmune = rooms.get(0).getInmune();
    }        
        
    
    //random pool of names for the inmunes
    public static String[] getNames(){
        final String[] names = {"Alphonse","Julian","Edwin","Chung","Nestor", "Refugia", "Peg", "Inocencia","Sau", "Venita","Nisha"};
        return names;
    }
        
    
    public String fight(int choice){
        Enemy enemy = currentRoom.getEnemy();
        if (choice == 1){
            if(mc.getSpeed() > enemy.getSpeed()){
                mc.attack(enemy);
                return enemy.randAction(mc);
            }
            else{
                String action = enemy.randAction(mc);
                mc.attack(enemy);
                return action;
            }
        }
        else if(choice == 2){
            if(mc.getSpeed() > enemy.getSpeed()){
                mc.defend();
                return enemy.randAction(mc);
            }
            else{
                String action = enemy.randAction(mc);
                mc.defend();
                return action;
            }
        }
        return "";
    }
        
    
    public void useItem(int choice){
        tempStats = mc.useItem(choice,tempStats);  
    }
        
   
    //stats are reset after a fight(these are obtained through potions)
    public void resetStats(){
        mc.setStrength(mc.getStrength() - tempStats[0]);
        mc.setDefence(mc.getDefence() - tempStats[1]);
        mc.setSpeed(mc.getSpeed() - tempStats[2]); 
        for(int i = 0;i<tempStats.length;i++){
            tempStats[i] = 0;
        }
    }
        
    
    public void obtainItem(){
        if(rooms.get(currentRoomNum).getInmune() instanceof weaponInmune){
            mc.setWeapon(rooms.get(currentRoomNum).getInmune().getItem());
            return;
        }
            mc.setInventory(rooms.get(currentRoomNum).getInmune().getItem());
    }
    
    
    public void obtainItem(int index){
        mc.setInventory(rooms.get(currentRoomNum).getInmune().getItem(),index);
    }
    
    
    //when the character goes back and goes forward again a new set of rooms will be created
    public String pickRoom(int nextRoomNum){
        currentRoom.generateRooms();
        Room nextRooms[] = rooms.get(currentRoomNum).getNextRooms();
        Room nextRoom = null;
        boolean gone = false;
        
        while(!gone && nextRoom == null){
            if (nextRoomNum == 4){
                try{
                    nextRoom = rooms.get(currentRoomNum - 1);
                    rooms.remove(currentRoomNum);
                    gone = true;
                    nextRoom.generateRooms();
                    currentRoom = rooms.get(currentRoomNum-1);
                    currentRoomNum--;
                    
                    return "gone";
                }
                catch(Exception e){
                    return("There isn't a way back");
                }
            }
            else{
                try {
                    nextRoom = nextRooms[nextRoomNum-1];
                    
                    rooms.add(nextRoom);
                    gone = true;
                    rooms.get(currentRoomNum +1).generateRooms();
                    currentRoom = rooms.get(currentRoomNum+1);
                    currentRoomNum++;
                    return "gone";
                }
                catch(Exception e){
                     return "This way is blocked";
                }
            }
        }
        currentRoom = rooms.get(currentRoomNum);
        return "gone";
    }
    
    
    public Room getCurrentRoom(){
        return currentRoom;
    }
        
    
    public int getCurrentRoomNum(){
        return currentRoomNum;
    }
        
    
    public Maincharacter getMC(){
        return mc;
    }
        
    
    public ArrayList<Room> getRooms(){
        return rooms;
    }
    
    
    public void generateRooms(){
        rooms.get(currentRoomNum).generateRooms();
    }
    
    
}
