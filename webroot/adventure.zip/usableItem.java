
public class usableItem extends item
{
    int speedBuff;
    int strengthBuff;
    int healthBuff;
    int defenceBuff;
    public usableItem(){
    }
    public usableItem(int type){
        if(type == 0){
            none();
        }
    }
    public void use(){
        return;
    }
    public void setStrength(int a){
        strengthBuff = a;
    }
    public void setSpeed(int a){
        speedBuff = a;
    }
    public void setHealth(int a){
        healthBuff = a;
    }
     public void setDefence(int a){
        defenceBuff = a;
    }
    
    public int getStrength(){
        return strengthBuff;
    }
    public int getSpeed(){
        return strengthBuff;
    }
    public int getHealth(){
        return healthBuff;
    }
    public int getDefence(){
        return defenceBuff;
    }
    private void none(){
        this.setName("nothing");
        this.notUsable();
        
    }

}
