import java.util.Random;
public class itemInmune extends Inmune
{
    public itemInmune()
    {
        super();
        int random = new Random().nextInt(4);
        if (random == 0){
            this.setOffering(new Healthpotion()); 
        }
        else if(random ==1){
            this.setOffering(new Speedpotion()); 
        }
        else if(random ==2){
            this.setOffering(new Strengthpotion()); 
        }
        else{
            this.setOffering(new Defencepotion());
        }
    }
        
    



}
