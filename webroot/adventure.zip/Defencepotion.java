
public class Defencepotion extends usableItem
{
    public Defencepotion()
    {
        super();
        this.setDefence(15);
        this.setName("Defence potion");
    }
}
