import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class Launcher implements ActionListener
{
    private JFrame frame;
    private JPanel panel; 
    private Game game;
    
    
    //Variables for the welcome screen
    private JButton startGame;
    private JButton loadGame;
    private JLabel startLabel;
    
    
    //variables for the start screen
    private JLabel chooseClassLabel;
    private JComboBox<String> classList;
    
    private JLabel nameLabel;
    private JTextField name;
    
    private JLabel startMessage;
    private JButton enterGame;
    
    
    //variables for the room choosing
    private JLabel whereLabel;
    
    private JButton rightButton;
    private JButton straightButton;
    private JButton leftButton;
    private JButton backwardsButton;
    
    private JButton saveButton;
    private JLabel roomLabel;
    
    
    //variables for inmune room
    private JLabel inmuneName;
    private JLabel inmuneOffering;
    private JLabel yesOrNo;
    
    private JButton yesButton;
    private JButton noButton;
    
    
    //variables for battle and boss room
    private JLabel mcHealth;
    private JLabel feed;
    private JLabel enemyHealth;
    private JLabel currentChar;
    private JLabel whatLabel;
    
    private JButton fightButton;
    private JButton defendButton;
    private JButton itemButton;
    
    
    //variables for item screen
    private JLabel itemLabel;
    private JButton firstItem;
    private JButton secondItem;
    private JButton thirdItem;
    private JButton back;
    
    
    //varibles for end screen (startgame button will be reused);
    private JLabel gameOverLabel;
    private JLabel roomScore;
    
    
    //varibles for full inventory screen(back button will be reused);
    private JLabel fullItems;
    private JButton fullFirst;
    private JButton fullSecond;
    private JButton fullThird;
    
    public static void main(){
        new Launcher();
    
    }
    public Launcher(){
        frame = new JFrame("Adventure game");
        frame.setSize(500,500);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        panel = new JPanel();
        
        startLabel = new JLabel("Welcome to the infected zone");
        startLabel.setHorizontalAlignment(JLabel.CENTER);
        
        startGame = new JButton("New Game");
        startGame.addActionListener(this);
        loadGame = new JButton("Load Game");
        loadGame.addActionListener(this);
        
        panel.setLayout(new GridLayout(3,1,10,10));
        panel.add(startGame);
        panel.add(startLabel);
        panel.add(loadGame);

        

        frame.setLocationRelativeTo(null);
        
        update();
      
        
        
    } 
    
    
    public void newGameScreen(){
        reset();
        panel.setLayout(new GridLayout(3,2,100,100));
        chooseClassLabel = new JLabel("Choose a class:");
        chooseClassLabel.setHorizontalAlignment(JLabel.CENTER);
        String[] classes = {"Patient","Strong","Quick"};
        classList = new JComboBox<String>(classes);
        
        nameLabel = new JLabel("Enter your name:");
        nameLabel.setHorizontalAlignment(JLabel.CENTER);
        name = new JTextField(1);
        
        
        startMessage = new JLabel("Press the button to begin!");
        startMessage.setHorizontalAlignment(JLabel.CENTER);
        enterGame = new JButton("Begin adventure");
        enterGame.addActionListener(this);
        
        
        
        panel.add(chooseClassLabel);
        panel.add(classList);
        panel.add(nameLabel);
        panel.add(name);
        panel.add(startMessage);
        panel.add(enterGame);

        update();
    }
    
    
    public void display(){
        reset();
        
        panel.setLayout(new GridLayout(3,3,25,25));
        
        saveButton = new JButton("Save game");
        saveButton.addActionListener(this);
        
        JPanel tempPanel = new JPanel();
        tempPanel.add(saveButton);
        
        whereLabel = new JLabel("Where will you go next?");
        
        leftButton = new JButton("Left");
        leftButton.addActionListener(this);
        
        straightButton = new JButton("Straight");
        straightButton.addActionListener(this);
        
        rightButton = new JButton("Right");
        rightButton.addActionListener(this);
        
        backwardsButton = new JButton("Back");
        backwardsButton.addActionListener(this);
        
        
        JPanel tempPanel1 = new JPanel();
        int currentRoomNum = (game.getCurrentRoomNum()+1);
        roomLabel = new JLabel("Room wave: " + currentRoomNum);
        

        
        panel.add(tempPanel);
        panel.add(straightButton);
        panel.add(roomLabel);
        panel.add(leftButton);
        panel.add(whereLabel);
        panel.add(rightButton);
        panel.add(new JLabel());
        panel.add(backwardsButton);
        panel.add(new JLabel());
    

        update();
    }
    
    
    public void roomDisplay(String feedUpdate){
        reset();
        game.generateRooms();
        
        if(game.getCurrentRoom() instanceof battleRoom || game.getCurrentRoom() instanceof bossRoom){
           if(game.getCurrentRoom().getEnemy().getCurrentHealth() < 0){
               game.pickRoom(4);
               display();
           }
           mcHealth = new JLabel(game.getMC().getName()+"'s health: " + game.getMC().getCurrentHealth());
            mcHealth.setHorizontalAlignment(JLabel.CENTER);
            whatLabel = new JLabel("What will " + game.getMC().getName()+ " do?");
            whatLabel.setHorizontalAlignment(JLabel.CENTER);
            feed = new JLabel(feedUpdate);
            feed.setHorizontalAlignment(JLabel.CENTER);
            enemyHealth = new JLabel("Enemy's health: " + game.getCurrentRoom().getEnemy().getCurrentHealth());
            enemyHealth.setHorizontalAlignment(JLabel.CENTER);
            if(game.getCurrentRoom().getEnemy() instanceof Infected){
                currentChar = new JLabel("Fighting: Infected");
                currentChar.setHorizontalAlignment(JLabel.CENTER);
            }
            else{
                currentChar = new JLabel("Fighting: Doctor");
                currentChar.setHorizontalAlignment(JLabel.CENTER);
            }
        
            fightButton = new JButton("Fight");
            fightButton.addActionListener(this);
            
            defendButton = new JButton("Defend");
            defendButton.addActionListener(this);
            
            itemButton = new JButton("Item");
            itemButton.addActionListener(this);
        
            panel.setLayout(new GridLayout(2,3));
            
            
            //Making panels for the top section of the main panel
            JPanel topLeftPanel = new JPanel();
            topLeftPanel.add(mcHealth);
            
            JPanel topCenterPanel = new JPanel();
            topCenterPanel.setLayout(new GridLayout(3,1));
            topCenterPanel.add(currentChar);
            topCenterPanel.add(whatLabel);
            topCenterPanel.add(feed);
            
            JPanel topRightPanel = new JPanel();
            topRightPanel.add(enemyHealth);
            

            panel.add(topLeftPanel);
            panel.add(topCenterPanel);
            panel.add(topRightPanel);
            panel.add(fightButton);
            panel.add(defendButton);
            panel.add(itemButton);
            

            
            update();
        
        
        }
        else{
            panel.setLayout(new GridLayout(3,1));
            inmuneName = new JLabel("You come across " + game.getCurrentRoom().getInmune().getName());
            inmuneName.setHorizontalAlignment(JLabel.CENTER);
            inmuneOffering = new JLabel("They offer you a "+ game.getCurrentRoom().getInmune().getItem().getName());
            inmuneOffering.setHorizontalAlignment(JLabel.CENTER);
            yesOrNo = new JLabel(game.getCurrentRoom().getInmune().greeting());
            
            
            yesButton = new JButton("Yes");
            yesButton.addActionListener(this);
            noButton = new JButton("No");
            noButton.addActionListener(this);
            
            JPanel topPanel = new JPanel();
            topPanel.setLayout(new GridLayout(2,1));
            topPanel.add(inmuneName);
            topPanel.add(inmuneOffering);
            
            JPanel middlePanel = new JPanel();
            middlePanel.add(yesOrNo);
            
            
            
            JPanel botPanel = new JPanel();
            botPanel.setLayout(new GridLayout(2,4,25,25));
            botPanel.add(new JLabel());
            botPanel.add(yesButton);
            botPanel.add(noButton);
            botPanel.add(new JLabel());
            
            botPanel.add(new JLabel());
            botPanel.add(new JLabel());
            botPanel.add(new JLabel());
            botPanel.add(new JLabel());
            
            
            panel.add(topPanel);
            panel.add(middlePanel);
            panel.add(botPanel);
        }
        update();
    }
    
    
    public void itemDrop(){
        reset();
            panel.setLayout(new GridLayout(3,1));
            
            inmuneName = new JLabel();
            inmuneName.setHorizontalAlignment(JLabel.CENTER);
            inmuneOffering = new JLabel("The enemy just dropped a " + game.getCurrentRoom().getEnemy().getItem().getName());
            inmuneOffering.setHorizontalAlignment(JLabel.CENTER);
            yesOrNo = new JLabel("Will you take it?");
            
            
            yesButton = new JButton("Yes");
            yesButton.addActionListener(this);
            noButton = new JButton("No");
            noButton.addActionListener(this);
            
            JPanel topPanel = new JPanel();
            topPanel.setLayout(new GridLayout(2,1));
            topPanel.add(inmuneName);
            topPanel.add(inmuneOffering);
            
            JPanel middlePanel = new JPanel();
            middlePanel.add(yesOrNo);
            
            
            
            JPanel botPanel = new JPanel();
            botPanel.setLayout(new GridLayout(2,4,25,25));
            botPanel.add(new JLabel());
            botPanel.add(yesButton);
            botPanel.add(noButton);
            botPanel.add(new JLabel());
            
            botPanel.add(new JLabel());
            botPanel.add(new JLabel());
            botPanel.add(new JLabel());
            botPanel.add(new JLabel());
            
            
            panel.add(topPanel);
            panel.add(middlePanel);
            panel.add(botPanel);
        
            update();
    
    
    
    }
    
    
    public void itemDisplay(){
        reset();
        
        panel.setLayout(new GridLayout(5,1));
        
        itemLabel = new JLabel("Choose an item");
        firstItem = new JButton(game.getMC().getInventory(0).getName());
        firstItem.addActionListener(this);
        secondItem = new JButton(game.getMC().getInventory(1).getName());
        secondItem.addActionListener(this);
        thirdItem = new JButton(game.getMC().getInventory(2).getName());
        thirdItem.addActionListener(this);
        back = new JButton("Go back");
        back.addActionListener(this);
        
        JPanel topPanel = new JPanel();
        topPanel.add(itemLabel);
        
        
        JPanel panel1 = new JPanel();
        panel1.add(firstItem);
        JPanel panel2 = new JPanel();
        panel2.add(secondItem);
        JPanel panel3 = new JPanel();
        panel3.add(thirdItem);
        
        panel.add(topPanel);
        panel.add(panel1);
        panel.add(panel2);
        panel.add(panel3);
        panel.add(back);
        update();
    
    }
    
    
    public void reset(){
        frame.remove(panel);
        panel = new JPanel(); 
    }
    
    
    public void update(){
        frame.add(panel);
        frame.setVisible(true);
    }
    
    
    public void loadGame(){
        File save = null;
        FileInputStream stream = null;
        Maincharacter mc = null;
        int currentRoomNum = 0;
        ArrayList<Room> rooms = new ArrayList<Room>();
        Room currentRoom = null;
        
        Room tempRoom;
        
        try{
            save = new File("save.txt");
            stream = new FileInputStream(save);
            
            
        }
        catch(Exception e){
            startLabel.setText("The file could not be loaded"); 
            return;
        }
        try{
            ObjectInputStream input = new ObjectInputStream(stream);
            game = (Game) input.readObject();
        }
        catch(ClassNotFoundException e){
        }
        catch(Exception e){
            startLabel.setText("The file format is wrong");
            return ;
        }
        display();
    }
    
    
    public void saveGame(){
        ArrayList<Room> rooms = new ArrayList<Room>();
        Room currentRoom = null;
        try{
            FileOutputStream output = new FileOutputStream("save.txt"); 
            ObjectOutputStream objOut = new ObjectOutputStream(output); 
            
            objOut.writeObject(game);
            output.close();
    
        }
        catch(Exception e){
             System.out.println(e.toString());
            whereLabel.setText("Error in saving game");
            
        }
    }
    
    public void gameOverDisplay(boolean won){
        reset();
        String text;
        
        panel.setLayout(new GridLayout(3,1));
        
        
        if(won){
           text = "You found the cure!";
        }
        else{
           text = "You died!";
        }
        gameOverLabel = new JLabel(text);
        gameOverLabel.setHorizontalAlignment(JLabel.CENTER);
        int currentRoomNum = (game.getCurrentRoomNum()+1);
        roomScore = new JLabel("Rooms passed: " + currentRoomNum);
        roomScore.setHorizontalAlignment(JLabel.CENTER);
        panel.add(gameOverLabel);
        panel.add(roomScore);
        panel.add(startGame);
        
        update();
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == startGame){
            newGameScreen();
        }
        else if(e.getSource() == loadGame){
            loadGame();
        }
        else if(e.getSource() == enterGame){
            int charType = classList.getSelectedIndex();
            String selectedName = name.getText();
            if(selectedName.equals("")){
                startMessage.setText("Enter a valid name!");
                return;
            }
            game = new Game(charType,selectedName);
            roomDisplay("");
        }
        else if(e.getSource() == yesButton){
            try{
               if(game.getCurrentRoom().getEnemy().getCurrentHealth() < 0){
                   game.getMC().setWeapon(game.getCurrentRoom().getEnemy().getItem());
                   display();
                   return;
                }
            }
            catch(Exception a){
            }
            if(game.getRooms().get(game.getCurrentRoomNum()).getInmune() instanceof itemInmune){
                if (game.getMC().getInventory(2).getName().equals("nothing")){
                    game.obtainItem();
                    display();
                }
                else{
                    fullInventory();
                }
            }
            else{
                game.obtainItem();
                display();
            }
        }
        else if(e.getSource() == noButton){
            display();
        }
        else if(e.getSource() == saveButton){
            saveGame();
        }
        else if(e.getSource() == leftButton){
             String message = game.pickRoom(1);
             if(message.equals("gone")){
                 roomDisplay("");
             }
             else{
                 whereLabel.setText(message);
              }
            }
        else if(e.getSource() == straightButton){
            String message = game.pickRoom(2);
            if(message.equals("gone")){
                roomDisplay("");
            }
            else{
                whereLabel.setText(message);
            }
        }
        else if (e.getSource() == rightButton){
            String message = game.pickRoom(3);
            if(message.equals("gone")){
                roomDisplay("");
            }
            else{
                whereLabel.setText(message);
            }
        }
        else if(e.getSource() == backwardsButton){
            String message = game.pickRoom(4);
            if(message.equals("gone")){
                roomDisplay("");
            }
            else{
                whereLabel.setText(message);
            }
        }
        else if(e.getSource() == fightButton){
            feed.setText(game.fight(1));
            fightUpdate();
        }
        else if(e.getSource() == defendButton){
            feed.setText(game.fight(2));
            fightUpdate();
        }
        else if(e.getSource() == itemButton){
            itemDisplay();
        }
        else if(e.getSource() == firstItem){
            if(firstItem.getText().equals("nothing")){
                itemLabel.setText("There is nothing in that slot!");
                return;
            }
            game.useItem(0);
            roomDisplay("");
        }
        else if(e.getSource() == secondItem){
            if(secondItem.getText().equals("nothing")){
                itemLabel.setText("There is nothing in that slot!");
                return;
            }
            game.useItem(1);
            roomDisplay("");
        }
        else if(e.getSource() == thirdItem){
            if(thirdItem.getText().equals("nothing")){
                itemLabel.setText("There is nothing in that slot!");
                return;
            }
            game.useItem(2);
            roomDisplay("");
        }
        else if(e.getSource() == back){
            roomDisplay("");
        }
        else if(e.getSource() == fullFirst){
            game.obtainItem(0);
            display();
        }
        else if(e.getSource() == fullSecond){
            game.obtainItem(1);
            display();
        }
        else if(e.getSource() == fullThird){
            game.obtainItem(2);
            display();
        }
    }
    
    
    public void fullInventory(){
        reset();
        
        panel.setLayout(new GridLayout(5,1));
        
        
        fullItems = new JLabel("Inventory is full, please replace an item");
        fullItems.setHorizontalAlignment(JLabel.CENTER);
        
        fullFirst = new JButton(game.getMC().getInventory(0).getName());
        fullFirst.addActionListener(this);
        
        fullSecond = new JButton(game.getMC().getInventory(1).getName());
        fullSecond.addActionListener(this);
        
        fullThird = new JButton(game.getMC().getInventory(2).getName());
        fullThird.addActionListener(this);
        
        back = new JButton("Cancel");
        back.addActionListener(this);
       
        JPanel topPanel = new JPanel();
        topPanel.add(fullItems);
        
        
        JPanel panel1 = new JPanel();
        panel1.add(fullFirst);
        JPanel panel2 = new JPanel();
        panel2.add(fullSecond);
        JPanel panel3 = new JPanel();
        panel3.add(fullThird);
        
        panel.add(topPanel);
        panel.add(panel1);
        panel.add(panel2);
        panel.add(panel3);
        panel.add(back);
    
    
    
    
        update();
    }
    
    
    public void fightUpdate(){
        if(game.getMC().getCurrentHealth() < 1){
            gameOverDisplay(false);
        }
        else if(game.getCurrentRoom().getEnemy().getCurrentHealth() < 1){
            
            if(game.getCurrentRoom().getEnemy() instanceof Doctor){
                gameOverDisplay(true);
                return;
            }
            itemDrop();
            
            game.resetStats();
        }
        else{
            mcHealth.setText(game.getMC().getName()+"'s health: " + game.getMC().getCurrentHealth());
            enemyHealth.setText("Enemy's health: " + game.getCurrentRoom().getEnemy().getCurrentHealth());
            roomDisplay(feed.getText());
        }
        
    }
}
