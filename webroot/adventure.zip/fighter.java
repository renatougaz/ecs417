


public interface fighter
{
   void defend();
   void attack(fighter enemy);
   void setCurrentHealth(int health);
   int getDefence();
   int getTempDefence();
   void setTempDefence(int defence);
   int getHealth();
   int getSpeed();
   String randAction(fighter enemy);
   void setDamage(int damage);
}
