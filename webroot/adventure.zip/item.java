import java.io.*;
abstract public class item implements Serializable
{
    private String name;
    private boolean usable;
    
    public String getName(){
        return name;
    }
        
    
    public void setName(String name){
        this.name = name;
    }
        
    
    public void notUsable(){
        usable = false;
    }
        
    
    public boolean getUsable(){
        return usable;
    }
   


}
