import java.util.Random;
final public class Doctor extends Enemy 
{


    public Doctor(String name)
    {
        super();
        this.setHealth(70);
        this.setSpeed(35);
        this.setTempDefence(0);
        this.setDefence(20);
        this.setStrength(35);
        this.setCurrentHealth(70);
    }
    public String randAction(fighter enemy){
        int choice =  new Random().nextInt(3) + 1;
        if (choice == 1){
            this.attack(enemy);
            return "Doctor attacks!";
        }
        else if(choice == 2){
            this.defend();
            return "Doctor deffends!";
        }
        else{
            specialAction(enemy);
            return "Doctor healed!";
        }
    }
    public void specialAction(fighter enemy){
        this.setCurrentHealth(getCurrentHealth() + new Random().nextInt(20)+10);
        if(this.getCurrentHealth() > this.getHealth()){
            this.setCurrentHealth(this.getHealth());
        }
    }
}
