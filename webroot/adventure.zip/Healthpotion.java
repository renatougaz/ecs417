

final public class Healthpotion extends usableItem
{
    public Healthpotion(){
        this.setHealth(30);
        this.setName("Health potion");
    }
    public void use(){
        
    }

    

}
