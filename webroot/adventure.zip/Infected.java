import java.util.Random;      
public class Infected extends Enemy {
    public Infected()
    {
        super();
        this.setHealth(30);
        this.setSpeed(30);
        this.setSpeed(20);
        this.setTempDefence(0);
        this.setDefence(0);
        this.setStrength(25);
        this.setCurrentHealth(45);
    }
    public String randAction(fighter enemy){
        int choice =  new Random().nextInt(3) + 1;
        if (choice == 1){
            this.attack(enemy);
            return "Infected attacks!";
        }
        else if(choice == 2){
            this.defend();
            return "Infected defends!";
        }
        else{
            return "Infected failed its attack!";
        }
    }

}
