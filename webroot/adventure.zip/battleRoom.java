

public class battleRoom extends Room
{
    Infected enemy;
    public battleRoom(int roomNum)
    {
        super(roomNum);
        enemy = new Infected();
    }
        
    
    public Infected getEnemy(){
        return enemy;
    }

}
