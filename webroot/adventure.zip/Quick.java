

public class Quick extends Maincharacter 
{
    public Quick(String name)
    {
        super(name);
        this.setSpeed(40);
        this.setStrength(10);
        this.setHealth(100);
        this.setDefence(10);
        this.setCurrentHealth(this.getHealth());
        this.setFirstWeapon(3);
    }
    public void useItem(){
        
    }
    public void specialAbility(){
    
        
    }

}
