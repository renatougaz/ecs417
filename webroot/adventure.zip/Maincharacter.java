
import java.util.Random;
import java.io.*;
abstract public class Maincharacter extends Character implements fighter,Serializable
{
    private int speed; //there are 4 levels for each attack and defense scenario
    private int strength;
    private int health;
    private int currentHealth;
    private int defence;
    private int tempDefence = 0;
    private int firstWeapon;
    private Weapon mainWeapon;
    private usableItem[] inventory = new usableItem[3];
    
    
    public Maincharacter(String name)
    {
        super(name);
        for(int i = 0; i < 3;i++)
        {
            inventory[i] = new usableItem(0);
        }
        mainWeapon = new Weapon(0);
    }
        
    
    public void setSpeed(int speed){
        this.speed = speed;
    }
        
    
    public int getSpeed(){
        return speed;
    }
        
    
    public int getStrength(){
        return strength;
    }
        
    
    public void setStrength(int strength){
        this.strength = strength;
    }
        
    
    public int getHealth(){
        return health;
    }
        
    
    public void setHealth(int health){
        this.health = health;
    }
        
    
    public int getCurrentHealth(){
        return currentHealth;
    }
        
    
    public void setCurrentHealth(int currentHealth){
        if (currentHealth > this.health){
            this.currentHealth = this.health;
        }
        else{
            this.currentHealth = currentHealth;
        }
    }
        
    
    public void setDamage(int damage){
        this.currentHealth -= damage;
    }
        
    
    public int getDefence(){
        return defence;
    }
        
    
    public void setDefence(int defence){
        this.defence = defence;
    }
        
    
    public int getTempDefence(){
        return tempDefence;
    }
        
    
    public Weapon getItem(){
        return mainWeapon;
    }
        
    
    public usableItem[] getInventory(){
        return inventory;
    }
        
    
    public item getInventory(int index){
        return inventory[index];
    }
        
    
    public int getFirstWeapon(){
        return firstWeapon;
    }
        
    
    public void setFirstWeapon(int firstWeapon){
        this.firstWeapon = firstWeapon;
    }
        
    
    public Weapon getWeapon(){
        return mainWeapon;
    }
        
    
    public void setWeapon(item weapon){
        mainWeapon = (Weapon) weapon;
    }
        
    
    public void setInventory(item potion){
        for(int i= 0; i<inventory.length; i++){
            if(inventory[i].getName().equals("nothing")){
                inventory[i] = (usableItem) potion;
                return;
            }
        }
    }
    
    
    public void setInventory(item potion,int index){
        inventory[index] = (usableItem) potion;
    }
    
    
    public void defend(){               
        tempDefence += this.strength * 0.5;
    }
        
    
    public void attack(fighter enemy){
        int damage = (int) (strength* 1.2 - enemy.getTempDefence()+enemy.getDefence());
        if (damage < 0){
            damage = 0;
        }
        enemy.setDamage(damage);
        enemy.setTempDefence(0);
    }
        
    
    public void setTempDefence(int defence){
        tempDefence = defence;
    }
        
    
    public String randAction(fighter enemy){
        int choice =  new Random().nextInt(2);
        if (choice == 0 ){
            this.attack(enemy);
            return "You attack";
        }
        else{
            this.defend();
            return "You defend";
        }
        
    }
        
    
    //keeps track of the addtional stats that the main character got from potions
    public int[] useItem(int itemIndex,int[]tempStats){
        usableItem potion = inventory[itemIndex];
        this.setStrength(this.getStrength()+potion.getStrength());
        this.setDefence(this.getDefence()+potion.getDefence());
        this.setSpeed(this.getSpeed()+potion.getSpeed());
        this.setCurrentHealth(this.getCurrentHealth()+potion.getHealth());
        tempStats[0] += potion.getStrength();
        tempStats[1] += potion.getDefence();
        tempStats[2] += potion.getSpeed();
        inventory[itemIndex] = new usableItem(0);
        return tempStats;
    }
    
    
}
