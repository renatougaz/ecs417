
import java.util.*;
public class safeRoom extends Room
{
    private Inmune inmune;
    public safeRoom(int roomNum)
    {
        super(roomNum);
        this.createInmune();
    }
    
    
    public safeRoom(int roomNum,int weaponType)
    {
        super();
        this.createInmune(weaponType);
        
    }
        
    
    public void createInmune(){
      int random = new Random().nextInt(4);
        
      if(random == 3){
            inmune = new weaponInmune();
      }
      else{
            inmune = new itemInmune();
      }
    }
        
    
    public void createInmune(int weaponType){
        inmune = new weaponInmune(weaponType);
    }
        
    
    public Inmune getInmune(){
        return inmune;
    }
    

}
