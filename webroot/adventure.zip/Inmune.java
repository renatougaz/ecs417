
import java.util.Random;
import java.io.*;
public abstract class  Inmune extends Character implements Serializable{   
    private item offering;
    private final String message;
    public Inmune(){   
        // all inmune names are random
        super(Game.getNames()[new Random(System.currentTimeMillis()).nextInt(Game.getNames().length)]);
        message = randMessage();
    }
    public static String randMessage(){
        final String[] messages ={"Here take this!","Do you want this?","Will you accept my gift?"};
        return messages[new Random().nextInt(messages.length)];
    }
    public item getItem(){
        return offering;
    }
    public void setOffering(item offering){
        this.offering = offering;
    }
    public String greeting(){
        return message;
    
    }
  }

