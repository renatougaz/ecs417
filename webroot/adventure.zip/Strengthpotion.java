
public class Strengthpotion extends usableItem
{

    public Strengthpotion()
    {
        super();
        this.setStrength(15);
        this.setName("Strength potion");
    }
}
